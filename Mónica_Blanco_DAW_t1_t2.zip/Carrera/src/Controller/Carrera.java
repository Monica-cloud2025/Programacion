package Controller;


public class Carrera
{
    private double kmTotales;
    private double vueltas;
    private Coche coche1;
    private Coche coche2;
    private Coche ganador;


    public Carrera()
    {
        Carrera carrera = new Carrera();
    }

    public Carrera(double kmTotales, double vueltas) {
        this.kmTotales = kmTotales;
        this.vueltas = vueltas;
        this.ganador = null;
    }

    public double getKmTotales() {
        return kmTotales;
    }

    public void setKmTotales(double kmTotales) {
        this.kmTotales = kmTotales;
    }

    public double getVueltas() {
        return vueltas;
    }

    public void setVueltas(double vueltas)
    {
        this.vueltas = vueltas;
    }
    public void asignarCoches(Coche coche1, Coche coche2)
    {
        this.coche1 = coche1;
        this.coche2 = coche2;
    }
    public void iniciarCarrera()
    {
        System.out.println("Datos de los participantes de la carrera son:");
        coche1.mostrarDatos();
        coche2.mostrarDatos();


        for (int i = 1; i < 11; i++)
        {
            System.out.println("\n---Vuelta " + i + "---");
            this.coche1.acelerar(Math.random() * 50);
            this.coche2.acelerar(Math.random() * 50);

            coche1.mostrarDatos();
            coche2.mostrarDatos();

            //si recorre los 50 km//
            if (this.coche1.getKmRecorridos() >= this.kmTotales)
            {
              this.ganador = this.coche1;
              break;
            } else
            {
                this.ganador = this.coche2;
            }

        }

            if (ganador != null)
            {
                System.out.println("El ganador ha sido el coche " + ganador.getMarca() + " con matrícula " + ganador.getMatricula());
            }

    }
}