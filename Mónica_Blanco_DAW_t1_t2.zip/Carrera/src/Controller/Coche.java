package Controller;
import java.util.Random;

public class Coche
{
    private String marca;
    private String modelo;
    private String matricula;
    private int cv;
    private int cc;
    private double velocidad;
    private double kmRecorridos;
    private Carrera carrera ;

    public Coche()
    {
        Carrera carrera = new Carrera();
    }

    public Coche(String marca, String modelo, String matricula, int cv, int cc)
    {
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.cv = cv;
        this.cc = cc;
        this.velocidad = 0;
        this.kmRecorridos = 0;
        this.carrera = carrera;
    }

    public String getMarca()
    {
        return marca;
    }

    public void setMarca(String marca)
    {
        this.marca = marca;
    }

    public String getModelo()
    {
        return modelo;
    }

    public void setModelo(String modelo)
    {
        this.modelo = modelo;
    }

    public String getMatricula()
    {
        return matricula;
    }

    public void setMatricula(String matricula)
    {
        this.matricula = matricula;
    }

    public int getCv()
    {
        return cv;
    }

    public void setCv(int cv)
    {
        this.cv = cv;
    }

    public int getCc()
    {
        return cc;
    }

    public void setCc(int cc)
    {
        this.cc = cc;
    }

    public double getVelocidad()
    {
        return velocidad;
    }

    public void setVelocidad(double velocidad)
    {
        this.velocidad = velocidad;
    }

    public double getKmRecorridos()
    {
        return kmRecorridos;
    }

    public void setKmRecorridos(double kmRecorridos)
    {
        this.kmRecorridos = kmRecorridos;
    }

    public Carrera getCarrera()
    {
        return carrera;
    }

    public void setCarrera(Carrera carrera)
    {
        this.carrera = carrera;
    }

    public void acelerar(double velocidadIncremental)
    {
        Random random = new Random();
        double velocidadAcelerar;

        if (this.cv < 100) {
            velocidadAcelerar = (int) (Math.random() * velocidadIncremental);
        } else {
            velocidadAcelerar = (int) (Math.random() * velocidadIncremental + 10);
        }

        this.velocidad += velocidadAcelerar;
        this.kmRecorridos += velocidadAcelerar * 0.5;

    }
    public void mostrarDatos()
    {

        System.out.println("Marca:"+this.marca);
        System.out.println("Modelo:"+this.modelo);
        System.out.println("Matrícula:"+this.matricula);
        System.out.println("CV:"+this.cv);
        System.out.println("CC:"+this.cc);
        System.out.println("Velocidad:"+this.velocidad+"km/h)");
        System.out.println("Km recorridos :"+this.kmRecorridos+" km ");
    }

}
