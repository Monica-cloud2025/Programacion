import Controller.Carrera;
import Controller.Coche;

public class Entrada
{
     public static void main(String[] args)
  {
      Coche coche1 = new Coche("Mercedes","GTR","1234ABC",585,3982);
      Coche coche2 = new Coche("BMW","M2","5678ZYV",480,2979);
      Carrera carrera = new Carrera(50,10);


      carrera.asignarCoches(coche1, coche2);
      carrera.iniciarCarrera();

  }
}
